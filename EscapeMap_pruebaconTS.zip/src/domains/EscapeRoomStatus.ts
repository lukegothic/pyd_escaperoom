export enum EscapeRoomStatus {
    PLAYED = 'PLAYED',
    NOT_PLAYED = 'NOT_PLAYED',
    WANT_TO_PLAY = 'WANT_TO_PLAY',
    DONT_WANT_TO_PLAY = 'DONT_WANT_TO_PLAY',
};
