import EscapeRoom from "./EscapeRoom";

export default class UserPreferences {
    test: string = "test";
    escapeRooms: Array<EscapeRoom> = [];
};
