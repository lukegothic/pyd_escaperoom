import { EscapeRoomStatus } from "./EscapeRoomStatus";

export default class EscapeRoom {
    id: string;
    status: EscapeRoomStatus = EscapeRoomStatus.NOT_PLAYED;
    finished: boolean = true;
};
