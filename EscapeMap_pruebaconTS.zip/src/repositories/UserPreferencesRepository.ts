import UserPreferences from "../domains/UserPreferences";
import StorageService from "../services/StorageService";

const UserPreferencesRepository = {
    get: (): UserPreferences => {
        return StorageService.get("UserPreferences") as UserPreferences;
    },
    set: (value: UserPreferences): boolean => {
        return StorageService.set("UserPreferences", value);
    }
}
export default UserPreferencesRepository;