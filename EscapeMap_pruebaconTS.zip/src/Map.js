import React, { useEffect, useRef } from "react";
import L from "leaflet";
import limites_provincias from './ES_limites_provincias';

const style = {
  flex: 1
};

function Map({ markersData }) {
  // create map
  const mapRef = useRef(null);
  useEffect(() => {
    mapRef.current = L.map("map", {
      center: [40.78612, 1.0737],
      zoom: 6,
      layers: [
        L.tileLayer("http://{s}.tile.osm.org/{z}/{x}/{y}.png", {
          attribution:
            '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
        })
      ]
    });
  }, []);

  // add layer
  const markerLayerRef = useRef(null);
  const limitLayerRef = useRef(null);

  useEffect(() => {
    markerLayerRef.current = L.layerGroup().addTo(mapRef.current);
    limitLayerRef.current = L.geoJSON(limites_provincias, { style: {
      color: "grey",
      fillColor: "black",
      fillOpacity: 0.1
    }}).addTo(mapRef.current);
  }, []);

  // update markers
  useEffect(
    () => {
      /*
      markerLayerRef.current.clearLayers();
      markersData.forEach(marker => {
        L.marker(marker.latLng, { title: marker.title }).addTo(
          markerLayerRef.current
        );
      });
      */
     if (markersData) {
       console.log(markersData);
        let marker_x_prov = {};
        markersData.forEach(marker => {
          if (marker_x_prov[marker.city.province.id] === undefined) {
            marker_x_prov[marker.city.province.id] = [];
          }
          marker_x_prov[marker.city.province.id].push(marker);
        });
        console.log(marker_x_prov);
        limitLayerRef.current.eachLayer(layer => {
          layer.setStyle({
            color: "grey",
            fillColor: "black",
            fillOpacity: 0.1
          });
          //layer.bindTooltip(""+layer.feature.properties.name+": "+marker_x_prov[layer.feature.properties.id]? marker_x_prov[layer.feature.properties.id].length : "NONE", { permanent: true });
          layer.bindTooltip(layer.feature.properties.name);
        });
      }
    },
    [markersData]
  );

  return <div id="map" style={style} />;
}

export default Map;
